const express = require('express');
const {body} = require('express-validator');
const controller = require('../controllers/userController')
const router = express.Router();
module.exports = router;
const {isGuest} = require('../middlewares/auth');
const {isLoggedIn} = require('../middlewares/auth');
const {logInLimiter} =  require('../middlewares/rateLimiter');
const {validateSignUp,validateLogIn,validateResult} =  require('../middlewares/validator');


router.get('/profile', isLoggedIn, controller.profile);

router.get('/newUser', isGuest, controller.signUp);

//GET /users/login: send html for logging in
router.get('/login', controller.getUserLogin);

//POST /users/login: authenticate user's login
router.post('/login', logInLimiter, isGuest, validateLogIn, validateResult, controller.login);


//POST /users: create a new user account
router.post('/', isGuest, validateSignUp, validateResult, controller.create);

router.get('/logout', isLoggedIn, controller.signout); 

router.get('/watchTrade',isLoggedIn,controller.userWatchList);


