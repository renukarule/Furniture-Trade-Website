const express = require('express');
const controller = require('../controllers/tradeController')
const router = express.Router();
const {isLoggedIn} = require('../middlewares/auth');
const {isAuthor} = require('../middlewares/auth');
const{validateId,validateTrade,validateResult} = require('../middlewares/validator');
const multer = require('multer');

module.exports = router;

//storage
const Storage = multer.diskStorage({
    destination: 'uploads',
});

const upload = multer({
    storage: Storage
}).single('imageURL')
  
//Routing for home page
router.get('/', controller.index);

//Routing for landing on new trade creation page
router.get('/newTrade', isLoggedIn, controller.new);

//Routing for landing on feedback page
router.get('/feedback',controller.feedback);

//Routing for landing on trades page
router.get('/:id', validateId,controller.show);

//Routing for creating new trade and submitting information
router.post('/', isLoggedIn, validateTrade, validateResult,controller.createNewTrade);
//isAuthor,

//Routing for editing trade
router.get('/:id/edit', validateId, isLoggedIn, isAuthor, controller.edit);

//Routing for updating trade
router.put('/:id', validateId, isLoggedIn, validateTrade, validateResult, isAuthor, controller.updateTradeByID);

//Routing for deleting trade
router.delete('/:id', validateId, isLoggedIn, isAuthor, controller.deleteTradeByID);

//Routing for watchlist
router.get('/:id/watchList',validateId,isLoggedIn,controller.addToWatchList)

router.get('/:id/removeFromWatchList',validateId,isLoggedIn,controller.removeFromWatchList)
