const express = require('express');
const controller = require('../controllers/tradeFeatureController');
const {isLoggedIn} = require('../middlewares/auth');
const {validateId} = require('../middlewares/validator')
const router = express.Router();

//get details for trading.
router.get('/makeOffer/:id',validateId,isLoggedIn,controller.createTrade)

//trade elements
router.post('/createTrade',isLoggedIn,controller.createTradeRequest);

// get user requested trades
router.get('/userRequestedTrades',isLoggedIn,controller.getTradeRequests);

//get incoming trade request for user
router.get('/inboundTradeRequestForUser',isLoggedIn,controller.getInboundTradeRequest);

//delete trade request
router.post('/deleteTradeRequest/:id',isLoggedIn,controller.deleteTrade);

//accept trade request
router.post('/acceptTradeRequest/:id',isLoggedIn,controller.acceptTrade);

//reject trade request
router.post('/rejectTradeRequest/:id',isLoggedIn,controller.rejectTrade);
module.exports = router;